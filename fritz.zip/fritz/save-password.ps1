﻿Param([Parameter(Mandatory = $True, Position = 0, HelpMessage = 'Password to store')][string]$password,
      [Parameter(Mandatory = $False, Position = 1, HelpMessage = 'Filename for encypted password')][string]$filename = "password.txt")    


ConvertTo-SecureString $password -AsPlainText -Force | 
    ConvertFrom-SecureString | 
        Out-File $filename

