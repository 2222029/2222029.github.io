﻿Param([Parameter(Mandatory = $False, Position = 1, HelpMessage = 'Filename for encypted password, for testing only')][string]$filename = "password.txt")    

function ConvertFrom-SecureStringToPlainText ([System.Security.SecureString]$SecureString) {

    [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
    
        [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
    )            
}

$encryptedPassword = Get-Content $filename | ConvertTo-SecureString

$password = ConvertFrom-SecureStringToPlainText $encryptedPassword

$password

$User = "User01"
$credential = New-Object -TypeName System.Management.Automation.PSCredential ($User, $encryptedPassword)

$credential

$password = $null

$credential = 0
