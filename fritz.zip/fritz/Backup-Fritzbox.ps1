Param([Parameter(Mandatory = $True, Position = 0, HelpMessage = 'credential to login to TR-064')][PSCredential]$credential,
      [Parameter(Mandatory = $False, Position = 1, HelpMessage = 'the IP address of the FRITZ!Box, defaults to fritz.box"')][string]$Address = "fritz.box")
# Allow TLS 10,11,12
#[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

#$ErrorActionPreference = "SilentlyContinue"

$toDay = Get-Date -format "yyyyMMdd-HHmm"
[string] $myScriptName = $MyInvocation.MyCommand.Path
[string] $localPath =(split-path $myScriptName)


set-location $localPath


# create a logger with config file
function get-logger {
    [string] $configFile = "$localPath\log4net.config"
    [string] $messageFormat = "[%date{yyyy-MM-dd HH:mm:ss.fff} [%level] `t - [%message]%n"#
    [string] $log4NetDLL = "$localPath\log4net.dll"
    # to be used by $configFile
    [string] $env:logPath = "$localPath\log" 

    # create logging object

    try {
        if ((test-path $configFile -ErrorAction SilentlyContinue) -ne $true) {throw "Config file missing at $configFile" } 
        [void][Reflection.Assembly]::LoadFile($log4NetDLL)
        [log4net.LogManager]::ResetConfiguration()
        [System.IO.FileInfo] $logConfigFile = new-Object System.IO.FileInfo( $configFile )
        [log4net.Config.XmlConfigurator]::Configure( $logConfigFile )
        [log4net.LogManager]::GetLogger("root")
    }
    catch
    {
        "Failed to load logger. Will exit."
        throw $_.Exception
    }
} 

function stop-logger {
    # Properly Close down the logger
    
[   log4net.LogManager]::Shutdown()
    [string] $env:logPath = ""
    $script:log=$null
}

function Get-FritzBoxBasicinfo {
  
    # Basic info for fritzbox as hashtable
    Param([Parameter(Mandatory = $False, Position = 0, HelpMessage = 'the IP address of the FRITZ!Box, defaults to fritz.box')][string]$Address = "fritz.box")
    
   $response=Invoke-WebRequest $("http://$Address" + ":49000/tr64desc.xml")
   $log.DEBUG("        Status code f�r tr64desc.xml : $($response.StatusCode)")
   $Content= [xml] $response.content
   $basicInfo=@{}
   $content.root.Device.ChildNodes | Foreach {$basicInfo[$_.Name] = $_."#text"}
   $content.root.systemVersion.ChildNodes | Foreach {$basicInfo[$_.Name] = $_."#text"}
   $basicInfo

}

function Get-FritzBoxSecurityPort
{
    Param([Parameter(Mandatory = $False, Position = 0, HelpMessage = 'the IP address of the FRITZ!Box, defaults to fritz.box')][string]$Address = "fritz.box")

    $contentType="text/xml"
    $headers=@{charset="utf-8";SOAPACTION='urn:dslforum-org:service:DeviceInfo:1#GetSecurityPort'}
    $uri="http://" + $Address + ":49000/upnp/control/deviceinfo"
    $body='<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:GetSecurityPort xmlns:u="urn:dslforum-org:service:DeviceInfo:1"></u:GetSecurityPort></s:Body></s:Envelope>'
    
    $response=Invoke-RestMethod -contenttype $contentType -Headers $headers -Uri $uri -Method Post -body $body

    $sslport = $response.Envelope.Body.GetSecurityPortResponse.NewSecurityPort
    return $sslport       
}

function test-FritzboxConnection {
    $proxy= "http://localhost:8888" 
    $SSLPort = Get-FritzBoxSecurityPort $Address
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
    $contentType="text/xml"
    $headers=@{charset="utf-8";SOAPACTION='urn:dslforum-org:service:ManagementServer:1#GetInfo'}
    $uri="https://" + $Address+ ":" + $SSLPort + "/upnp/control/mgmsrv"
    $body='<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:GetInfo xmlns:u="urn:dslforum-org:service:ManagementServer:1"></u:GetInfo></s:Body></s:Envelope>'
    
    $response=Invoke-RestMethod -contenttype $contentType -Headers $headers -Uri $uri -Method Post -body $body -Credential $credential


    if ($response.Envelope.body.GetInfoResponse.u -Match "urn:dslforum-org:service:ManagementServer:1") {
        $log.INFO("        Fritzbox auf Adresse $Address gefunden, Anmeldung erfolgreich")
    }
    else {
        $log.WARN("        Anmeldung an Fritzbox $Address nicht erfolgreich, Sript endet.")
        endScript
    }

}

function backup-Fritzbox {
   param(
        [Parameter(Mandatory = $true, HelpMessage = 'encryption password for Backup file')] [String] $password,
        [Parameter(Mandatory = $true, HelpMessage = 'an authenticated Webclient')] [String] $backupfile
    )
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
    $BackupFullname="$localPath\out\$backupfile"
    $log.INFO("    Name f�r Backupfile : $BackupFullname")
    $SSLPort = Get-FritzBoxSecurityPort $Address
    $contentType="text/xml"
    $headers=@{charset="utf-8";SOAPACTION='urn:dslforum-org:service:DeviceConfig:1#X_AVM-DE_GetConfigFile'}
    $uri="https://" + $Address + ":" + $SSLPort + "/upnp/control/deviceconfig"
    $body='<?xml version="1.0"?>
        <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"
        s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
        <s:Body> ' +
        '<u:X_AVM-DE_GetConfigFile xmlns:u="urn:dslforum-org:service:DeviceConfig:1">
        <NewX_AVM-DE_Password>' + $password + '</NewX_AVM-DE_Password>
        </u:X_AVM-DE_GetConfigFile>' +
        '</s:Body>
        </s:Envelope>'
    
    $response=Invoke-RestMethod -contenttype $contentType -Headers $headers -Uri $uri -Method Post -body $body -credential $credential

    $backupUrl=$response.Envelope.Body.'X_AVM-DE_GetConfigFileResponse'.'NewX_AVM-DE_ConfigFileUrl'
    $log.Info("    Original Url des Backupfile: $backupURL")
    $backupUrl=$backupUrl -replace "\[.*?\]", $Address
    $log.Info("    Url mit bekannter Adresse der Fritzbox: $backupURL")
    # Workaround, if TLS session ticket empty with 
    Invoke-Webrequest -Method Get -Uri $backupUrl -OutFile $BackupFullname -Credential $credential -ErrorAction SilentlyContinue
    # Authentication problem
    #$WebClient = New-Object System.Net.WebClient
    #$WebClient.Encoding=[System.Text.Encoding]::UTF8
    #$WebClient.Credentials = New-Object System.Net.NetworkCredential($Username, $Password)
    #$webClient.DownloadFile( $backupUrl, $BackupFullname)

    
if (Test-Path $BackupFullname) {
        $size=$(get-item $BackupFullname).Length
        $log.INFO("    Backupfile " + $BackupFullname + " wurde erstellt")
        $log.INFO("    Backupfilegr�sse ist $size")

    } else {
        $log.ERROR("    Kein Backupfile, script endet")
        #endScript
    }
}

function endScript {
    $log.INFO("End")
    $script:password=$null
    $script:firstresponse=$null
    stop-logger
    exit
}

$log= get-logger

$log.INFO("Start")

# get password from securestring, in memory only
$username=$credential.username
$password = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($credential.password)
$password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($password)

$log.INFO("    Adresse der Fritzbox: $Address")
$log.INFO("    Anmeldename         : $username")
$log.INFO("    Passwortl�nge       : $($password.length)")



# Get basic system information
$basicInfo=get-FritzBoxBasicInfo $Address

$log.INFO("    Modell          : $($basicInfo.friendlyName)")
$log.INFO("    Hardware Version: $($basicInfo.HW)")
$log.INFO("    Softwareversion : $($basicInfo.Display)")
$log.INFO("    Software Build  : $($basicInfo.BuildNumber)")


# test fritzbox connection

test-FritzboxConnection

# Backup Fritzbox

backup-FritzBox -password $Password -backupfile $("test_"+ $toDay + ".export")

endScript